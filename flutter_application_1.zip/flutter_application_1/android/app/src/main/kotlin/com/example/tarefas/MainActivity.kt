package com.example.tarefas

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
