import 'package:flutter/material.dart';
import 'package:tarefas/Pages/login.dart';

void main() {
  runApp(Tarefas());
}

class Tarefas extends StatelessWidget {
  const Tarefas({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(debugShowCheckedModeBanner: false, home: Login());
  }
}
