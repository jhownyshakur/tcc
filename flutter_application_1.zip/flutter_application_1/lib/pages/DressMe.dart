import 'package:flutter/material.dart';

class DressMe extends StatefulWidget {
  const DressMe({super.key});

  @override
  State<DressMe> createState() => _DressMeState();
}

class _DressMeState extends State<DressMe> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}